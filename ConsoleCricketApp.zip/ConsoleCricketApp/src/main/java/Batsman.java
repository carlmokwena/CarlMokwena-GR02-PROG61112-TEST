import java.util.Scanner;

// Abstract class for Batsman
abstract class Batsman {
    protected String name;
    
    public Batsman(String name) {
        this.name = name;
    }
    
    // Abstract method to get total runs
    public abstract int getTotalRuns();
    
    // Concrete method to print basic info
    public void printName() {
        System.out.println("Batsman: " + name);
    }
}

// Concrete class implementing the interface-like behavior
class CricketBatsman extends Batsman {
    private int[] stadiumRuns; // Runs at 4 stadiums
    private String[] stadiums = {"Wanderers", "Kingsmead", "St George's", "Newlands"};
    
    public CricketBatsman(String name, int[] runs) {
        super(name);
        this.stadiumRuns = runs;
    }
    
    @Override
    public int getTotalRuns() {
        int total = 0;
        for (int r : stadiumRuns) {
            total += r;
        }
        return total;
    }
    
    // Method to print full report
    public void printReport() {
        printName();
        for (int i = 0; i < stadiumRuns.length; i++) {
            System.out.println("Runs at " + stadiums[i] + ": " + stadiumRuns[i]);
        }
        System.out.println("Total Runs: " + getTotalRuns());
    }
}

// Main app with console input
 class ConsoleCricketApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter batsman name: ");
        String name = scanner.nextLine();
        
        int[] runs = new int[4];
        for (int i = 0; i < 4; i++) {
            System.out.print("Enter runs at " + stadiums[i] + ": ");  // Wait, need to define stadiums here or global
            runs[i] = scanner.nextInt();
        }
        
        CricketBatsman batsman = new CricketBatsman(name, runs);
        System.out.println("\n=== REPORT ===");
        batsman.printReport();
        
        scanner.close();
    }
    
    // Static array for stadiums (simple fix)
    private static String[] stadiums = {"Wanderers", "Kingsmead", "St George's", "Newlands"};
}
