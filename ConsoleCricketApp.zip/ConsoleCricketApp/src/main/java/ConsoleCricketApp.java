import java.util.Arrays;

// Main class for the application
public class ConsoleCricketApp {
    public static void main(String[] args) {
        // Create instances for 3 batsmen with their runs at stadiums
        // Stadiums: 1. Wanderers, 2. Kingsmead, 3. St George's (adjusted for 3)
        // Approximate Test runs from research: Kallis ~1200 at Wanderers, AB ~800 at Kingsmead, Amla ~600 at St George's
        CricketReport kallis = new CricketReport("Jacques Kallis", new int[]{1200, 500, 700});
        CricketReport ab = new CricketReport("AB de Villiers", new int[]{900, 800, 400});
        CricketReport amla = new CricketReport("Hashim Amla", new int[]{600, 700, 600});

        // Display reports
        System.out.println("=== CRICKET STADIUM RUNS REPORT ===");
        kallis.printReport();
        ab.printReport();
        amla.printReport();
    }
}

// CricketReport class with constructor and print method
class CricketReport {
    private String batsmanName;
    private int[] runs; // Array for runs at 3 stadiums
    private String[] stadiums = {"Wanderers", "Kingsmead", "St George's"};

    // Constructor: accepts batsman name and runs array
    public CricketReport(String name, int[] stadiumRuns) {
        this.batsmanName = name;
        this.runs = stadiumRuns;
    }

    // Method to print the report for this batsman
    public void printReport() {
        int total = 0;
        System.out.println("\nBatsman: " + batsmanName);
        for (int i = 0; i < runs.length; i++) {
            System.out.println("Runs at " + stadiums[i] + ": " + runs[i]);
            total += runs[i];
        }
        System.out.println("Total Runs: " + total);
    }
}